## ----style, echo=FALSE, results='asis'----------------------------------------
BiocStyle::markdown()

## ----echo=FALSE, fig.width=20, fig.height=10----------------------------------
knitr::include_graphics("FlexAssays.svg", dpi = 300)

## ----message=FALSE------------------------------------------------------------
library(FlexAssays)

# Define a helper function to generate random sparse matrices
generate_sparse_matrix <- function(nrow, ncol, density = 0.75) {
  mat1 <- Matrix::rsparsematrix(nrow = nrow, ncol = ncol, density = density)
  rownames(mat1) <- sample(LETTERS, nrow(mat1))
  colnames(mat1) <- sample(letters, ncol(mat1))
  return(mat1)
}

## -----------------------------------------------------------------------------
m1 <- generate_sparse_matrix(10, 6)
m2 <- generate_sparse_matrix(8, 13)

fa1 <- FlexAssays(list(m1, m2))
fa1

## -----------------------------------------------------------------------------
fa2 <- FlexAssays(m1)
fa2

## -----------------------------------------------------------------------------
fa3 <- FlexAssays(fa1)
fa3

## -----------------------------------------------------------------------------
fa4 <- FlexAssays(rownames = sample(LETTERS, 10), colnames = sample(letters, 8))
fa4

## ----error = TRUE-------------------------------------------------------------
fa4 <- FlexAssays(
  m1,
  rownames = sample(LETTERS, 10), 
  colnames = sample(letters, 8)
)

## -----------------------------------------------------------------------------
rowMap(fa1)

## -----------------------------------------------------------------------------
colMap(fa1)

## -----------------------------------------------------------------------------
dim(fa1)

## -----------------------------------------------------------------------------
rownames(fa1)

## -----------------------------------------------------------------------------
colnames(fa1)

## -----------------------------------------------------------------------------
length(fa1)

## -----------------------------------------------------------------------------
names(fa1) <- c("aa", "bb")
names(fa1)

## -----------------------------------------------------------------------------
getAssays(fa1)

## -----------------------------------------------------------------------------
getAssays(fa1)[[1]]

## -----------------------------------------------------------------------------
getAssays(fa1)[[2]]

## -----------------------------------------------------------------------------
m2

## -----------------------------------------------------------------------------
getAssays(fa1, withDimnames = FALSE)[[2]]

## -----------------------------------------------------------------------------
getOneAssay(fa1, 2)

## -----------------------------------------------------------------------------
fa1[[1]]

## -----------------------------------------------------------------------------
fa1[['aa']]

## -----------------------------------------------------------------------------
fa1$bb

## -----------------------------------------------------------------------------
# Add a new assay to the FlexAssays object
m3 <- generate_sparse_matrix(10, 8)
fa1[["m3"]] <- m3
fa1

## -----------------------------------------------------------------------------
m4 <- generate_sparse_matrix(4, 8)
fa1$m4 <- m4
fa1

## -----------------------------------------------------------------------------
m3 <- generate_sparse_matrix(6, 5)
m4 <- generate_sparse_matrix(4, 8)
fa1[[3]] <- m3
fa1$m4 <- m4
fa1

## -----------------------------------------------------------------------------
fa1$m4 <- NULL
fa1

## -----------------------------------------------------------------------------
fa1$m3[1, ] <- 1
fa1$m3

## -----------------------------------------------------------------------------
rownames(fa1) <- paste0("AAA_", rownames(fa1))
colnames(fa1) <- paste0("BBB_", colnames(fa1))
fa1

## -----------------------------------------------------------------------------
fa1$m3

## -----------------------------------------------------------------------------
fa1[1:4, 1:5]

## -----------------------------------------------------------------------------
fa1[rownames(fa1)[1:4], colnames(fa1)[1:5]]

## -----------------------------------------------------------------------------
fa1[rownames(fa1) %in% paste0("AAA_", LETTERS[1:10]), ]

## -----------------------------------------------------------------------------
# This will make 'm3' empty
fa2 <- fa1[!rownames(fa1) %in% rownames(fa1$m3), ]
fa2

## -----------------------------------------------------------------------------
fa2 <- fa1[!rownames(fa1) %in% rownames(fa1$m3), , drop = FALSE]
fa2

## -----------------------------------------------------------------------------
fa1$m3 <- NULL
rowMap(fa1)

## -----------------------------------------------------------------------------
fa1 <- cleanDimMaps(fa1)
rowMap(fa1)

## -----------------------------------------------------------------------------
fa1 <- FlexAssays(list(m1, m2))
rowFlex(fa1)

## -----------------------------------------------------------------------------
rownames(fa1)

## -----------------------------------------------------------------------------
m3 <- generate_sparse_matrix(6, 12)
rownames(m3)[1:3] <- setdiff(LETTERS, c(rownames(fa1), rownames(m3)))[1:3]
fa1$m3 <- m3
rownames(fa1)

## ----error = TRUE-------------------------------------------------------------
fa1 <- FlexAssays(list(m1, m2), rowFlex = "bounded")
fa1$m3 <- m3

## ----error = TRUE-------------------------------------------------------------
# Create an empty FlexAssays with pre-defined row names
fa2 <- FlexAssays(rownames = LETTERS[1:6], rowFlex = "bounded")

rownames(m3) <- LETTERS[4:9]
fa2$m3 <- m3

## -----------------------------------------------------------------------------
rownames(m3) <- rownames(fa2)[1:nrow(m3)]
fa2$m3 <- m3
fa2

## ----error = TRUE-------------------------------------------------------------
# Create an empty FlexAssays with pre-defined row/column names
fa2 <- FlexAssays(
  rownames = LETTERS[1:6], rowFlex = "bounded",
  colnames = letters[1:15], colFlex = "bounded"
)
rownames(m3) <- rownames(fa2)[1:nrow(m3)]
colnames(m3) <- letters[10:21]
fa2$m3 <- m3

## -----------------------------------------------------------------------------
colnames(m3) <- letters[1:ncol(m3)]
fa2$m3 <- m3
fa2

## ----error = TRUE-------------------------------------------------------------
m1 <- generate_sparse_matrix(6, 7)
m2 <- generate_sparse_matrix(4, 7)
colnames(m2) <- setdiff(letters, colnames(m1))[1:ncol(m2)]

# Error
FlexAssays(list(m1, m2), colFlex = "fixed")

## -----------------------------------------------------------------------------
colnames(m2) <- colnames(m1)
fa1 <- FlexAssays(list(m1, m2), colFlex = "fixed")
fa1

## ----error = TRUE-------------------------------------------------------------
m3 <- generate_sparse_matrix(5, 7)
colnames(m3)[1:3] <- setdiff(letters, colnames(fa1))[1:3]
fa1$m3 <- m3

## -----------------------------------------------------------------------------
colnames(m3) <- sample(colnames(fa1))
fa1$m3 <- m3
fa1

## ----error = TRUE-------------------------------------------------------------
m1 <- generate_sparse_matrix(4, 6)
m2 <- generate_sparse_matrix(5, 3)
m3 <- generate_sparse_matrix(8, 5)

m2 <- as(m2, "RsparseMatrix")
m3 <- as.matrix(m3)  ## Invalid assayClasses

assayClasses <- c("CsparseMatrix", "RsparseMatrix")
fa1 <- FlexAssays(list(m1, m2, m3), assayClasses = assayClasses)

## ----error = TRUE-------------------------------------------------------------
fa1 <- FlexAssays(list(m1, m2), assayClasses = assayClasses)
fa1$m3 <- m3

## -----------------------------------------------------------------------------
sessionInfo()

